
export const NORTHEAST_STATES = [
  "Arunachal Pradesh",
  "Assam",
  "Manipur",
  "Meghalaya",
  "Mizoram",
  "Nagaland",
  "Sikkim",
  "Tripura"
];

export const GENDERS = ["Male", "Female", "Other"];
export const CATEGORIES = ["ST", "SC", "OBC", "GEN"];
export const YES_NO = ["Yes", "No"];

export const ADMIN_PASSWORD = "NEHHDC@2025";
