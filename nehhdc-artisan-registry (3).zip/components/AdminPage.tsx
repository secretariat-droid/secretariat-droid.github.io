
import React, { useState, useMemo, FormEvent, ChangeEvent } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useArtisanContext } from '../App';
import { Artisan, CraftType } from '../types';
import { NORTHEAST_STATES } from '../constants';

const AdminLogin = () => {
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const { login } = useArtisanContext();
    const navigate = useNavigate();

    const handleSubmit = (e: FormEvent) => {
        e.preventDefault();
        setError('');
        if (login(password)) {
            navigate('/admin/dashboard', { replace: true });
        } else {
            setError('Incorrect password. Please try again.');
        }
    };

    return (
        <div className="flex items-center justify-center py-12">
            <div className="w-full max-w-md">
                <div className="bg-white p-8 rounded-2xl shadow-xl">
                    <h2 className="text-3xl font-extrabold text-center text-gray-800 mb-6">Admin Login</h2>
                    <form onSubmit={handleSubmit} className="space-y-6">
                        <div>
                            <label htmlFor="password-admin" className="sr-only">Password</label>
                            <input
                                id="password-admin"
                                name="password"
                                type="password"
                                required
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                placeholder="Password"
                                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition duration-150 ease-in-out"
                            />
                        </div>
                        {error && <p className="text-red-500 text-sm text-center">{error}</p>}
                        <div>
                            <button
                                type="submit"
                                className="w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-md text-white font-bold bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition duration-300"
                            >
                                Login
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
};

const AdminDashboard = () => {
    const { artisans, logout } = useArtisanContext();
    const navigate = useNavigate();

    const [searchTerm, setSearchTerm] = useState('');
    const [stateFilter, setStateFilter] = useState('');
    const [craftFilter, setCraftFilter] = useState('');
    
    const handleLogout = () => {
        logout();
        navigate('/admin');
    };

    const filteredArtisans = useMemo(() => {
        return artisans.filter(artisan => {
            const nameMatch = artisan.fullName.toLowerCase().includes(searchTerm.toLowerCase());
            const stateMatch = stateFilter ? artisan.state === stateFilter : true;
            const craftMatch = craftFilter ? artisan.craftType === craftFilter : true;
            return nameMatch && stateMatch && craftMatch;
        });
    }, [artisans, searchTerm, stateFilter, craftFilter]);

    const exportToCSV = () => {
        const headers = ['Name', 'State', 'District', 'Craft', 'Phone', 'Email', 'Certification'];
        const rows = filteredArtisans.map(a => [a.fullName, a.state, a.district, a.craftType, a.phone, a.email, a.certification].join(','));
        const csvContent = "data:text/csv;charset=utf-8," + [headers.join(','), ...rows].join('\n');
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "artisan_registry.csv");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    return (
        <div className="bg-white p-4 sm:p-6 rounded-2xl shadow-xl w-full">
            <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
                <h2 className="text-2xl font-bold text-gray-800">Artisan Records ({filteredArtisans.length})</h2>
                 <button onClick={handleLogout} className="w-full sm:w-auto bg-red-500 text-white font-bold py-2 px-4 rounded-lg shadow-md hover:bg-red-600 transition duration-300">
                    Logout
                </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
                <input
                    type="text"
                    placeholder="Search by name..."
                    value={searchTerm}
                    onChange={(e: ChangeEvent<HTMLInputElement>) => setSearchTerm(e.target.value)}
                    className="w-full p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                />
                <select value={stateFilter} onChange={(e: ChangeEvent<HTMLSelectElement>) => setStateFilter(e.target.value)} className="w-full p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none">
                    <option value="">All States</option>
                    {NORTHEAST_STATES.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
                <select value={craftFilter} onChange={(e: ChangeEvent<HTMLSelectElement>) => setCraftFilter(e.target.value)} className="w-full p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none">
                    <option value="">All Crafts</option>
                    <option value={CraftType.Handloom}>{CraftType.Handloom}</option>
                    <option value={CraftType.Handicraft}>{CraftType.Handicraft}</option>
                </select>
                <button onClick={exportToCSV} className="w-full bg-green-600 text-white font-bold py-2.5 px-4 rounded-lg shadow-md hover:bg-green-700 transition duration-300">
                    Export CSV
                </button>
            </div>

            <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-100">
                        <tr>
                            {['Photo', 'Name', 'State', 'District', 'Craft', 'Phone', 'Email', 'Certification'].map(header => (
                                <th key={header} scope="col" className="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase tracking-wider">{header}</th>
                            ))}
                        </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                        {filteredArtisans.map((artisan: Artisan, index: number) => (
                            <tr key={artisan.id} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                                <td className="px-6 py-4 whitespace-nowrap">
                                    <div className="flex-shrink-0 h-10 w-10">
                                        {artisan.photo ? <img className="h-10 w-10 rounded-full object-cover" src={artisan.photo} alt={artisan.fullName} /> : <div className="h-10 w-10 rounded-full bg-gray-300 flex items-center justify-center text-gray-500 font-bold text-sm">N/A</div>}
                                    </div>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{artisan.fullName}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">{artisan.state}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">{artisan.district}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">{artisan.craftType}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">{artisan.phone}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">{artisan.email}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">{artisan.certification || 'N/A'}</td>
                            </tr>
                        ))}
                         {filteredArtisans.length === 0 && (
                            <tr>
                                <td colSpan={8} className="text-center py-10 text-gray-500">No records found.</td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
};


const AdminPage = () => {
    const { isAuthenticated } = useArtisanContext();
    const location = useLocation();

    // Determine which component to show based on auth state and current path
    if (location.pathname === '/admin/dashboard' && isAuthenticated) {
        return <AdminDashboard />;
    }
    
    return <AdminLogin />;
};

export default AdminPage;
