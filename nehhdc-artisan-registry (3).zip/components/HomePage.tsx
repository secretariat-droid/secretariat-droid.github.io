
import React from 'react';
import { Link } from 'react-router-dom';
import { CraftType } from '../types';

const HomeButton = ({ to, children }: { to: string, children: React.ReactNode }) => (
    <Link to={to} className="w-full sm:w-80 text-center bg-blue-600 text-white font-bold py-4 px-8 rounded-xl shadow-lg hover:bg-blue-700 transition-transform transform hover:scale-105 duration-300 ease-in-out">
        {children}
    </Link>
);

const HomePage = () => {
    return (
        <div className="flex flex-col items-center justify-center text-center py-10 sm:py-20">
            <div className="bg-white p-8 sm:p-12 rounded-2xl shadow-xl w-full max-w-4xl">
                <h2 className="text-3xl sm:text-5xl font-extrabold text-gray-800 mb-4">
                    NEHHDC Artisan Registry
                </h2>
                <p className="text-base sm:text-lg text-gray-600 mb-12">
                    Register artisans in Handloom and Handicrafts across Northeast India.
                </p>
                <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
                    <HomeButton to={`/register/${CraftType.Handloom}`}>
                        Handloom Artisan Registration
                    </HomeButton>
                    <HomeButton to={`/register/${CraftType.Handicraft}`}>
                        Handicraft Artisan Registration
                    </HomeButton>
                </div>
            </div>
        </div>
    );
};

export default HomePage;
