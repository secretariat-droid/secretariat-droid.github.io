
import React, { useState, ChangeEvent, FormEvent } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useArtisanContext } from '../App';
import { Artisan, CraftType } from '../types';
import { NORTHEAST_STATES, GENDERS, CATEGORIES, YES_NO } from '../constants';

const initialFormData = {
    fullName: '', parentName: '', dob: '', gender: GENDERS[0], aadhaar: '', phone: '', email: '', education: '', photo: null,
    address: '', state: NORTHEAST_STATES[0], district: '', pincode: '', category: CATEGORIES[0], minority: YES_NO[1], otherId: '',
    bankName: '', accountNumber: '', ifscCode: '', experience: '', training: YES_NO[1], trainingDetails: '', certification: '',
};

const Card = ({ children }: { children: React.ReactNode }) => (
    <div className="bg-white rounded-xl shadow-md overflow-hidden mb-8">{children}</div>
);

const SectionHeader = ({ title }: { title: string }) => (
    <div className="bg-gray-100 p-4 border-b border-gray-200">
        <h3 className="text-lg font-bold text-gray-700">{title}</h3>
    </div>
);

const Input = (props: React.InputHTMLAttributes<HTMLInputElement>) => (
    <input {...props} className={`w-full p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition duration-150 ease-in-out ${props.className}`} />
);

const Select = (props: React.SelectHTMLAttributes<HTMLSelectElement>) => (
    <select {...props} className={`w-full p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition duration-150 ease-in-out ${props.className}`} />
);

const Textarea = (props: React.TextareaHTMLAttributes<HTMLTextAreaElement>) => (
    <textarea {...props} className={`w-full p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition duration-150 ease-in-out ${props.className}`} />
);

const Label = ({ children, htmlFor, required }: { children: React.ReactNode; htmlFor: string, required?: boolean }) => (
    <label htmlFor={htmlFor} className="block text-sm font-medium text-gray-700 mb-1">
        {children}{required && <span className="text-red-500 ml-1">*</span>}
    </label>
);

const RegistrationPage = () => {
    const { craftType } = useParams<{ craftType: CraftType }>();
    const { addArtisan } = useArtisanContext();
    const navigate = useNavigate();

    const [formData, setFormData] = useState<Omit<Artisan, 'id' | 'craftType'>>({
        ...initialFormData,
    });
    const [isSubmitted, setIsSubmitted] = useState(false);

    const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            const reader = new FileReader();
            reader.onloadend = () => {
                setFormData(prev => ({ ...prev, photo: reader.result as string }));
            };
            reader.readAsDataURL(file);
        }
    };

    const handleSubmit = (e: FormEvent) => {
        e.preventDefault();
        if (!craftType) return;
        addArtisan({ ...formData, craftType });
        setIsSubmitted(true);
        window.scrollTo(0, 0);
    };

    if (isSubmitted) {
        return (
            <div className="max-w-3xl mx-auto">
                <Card>
                    <div className="p-8 text-center">
                        <svg className="w-16 h-16 mx-auto text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                        <h2 className="text-2xl font-bold text-gray-800 mt-4">Registration Successful!</h2>
                        <p className="text-gray-600 mt-2">You have successfully registered with NEHHDC.com</p>
                        <button onClick={() => navigate('/')} className="mt-8 w-full sm:w-auto bg-blue-600 text-white font-bold py-3 px-6 rounded-lg shadow-md hover:bg-blue-700 transition duration-300">
                            Back to Home
                        </button>
                    </div>
                </Card>
            </div>
        );
    }

    return (
        <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-6 text-center">{craftType} Artisan Registration</h2>
            <form onSubmit={handleSubmit}>
                <Card>
                    <SectionHeader title="Basic Details" />
                    <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div><Label htmlFor="fullName" required>Full Name</Label><Input type="text" name="fullName" id="fullName" value={formData.fullName} onChange={handleChange} required /></div>
                        <div><Label htmlFor="parentName" required>Father’s/Mother’s Name</Label><Input type="text" name="parentName" id="parentName" value={formData.parentName} onChange={handleChange} required /></div>
                        <div><Label htmlFor="dob" required>Date of Birth</Label><Input type="date" name="dob" id="dob" value={formData.dob} onChange={handleChange} required /></div>
                        <div><Label htmlFor="gender" required>Gender</Label><Select name="gender" id="gender" value={formData.gender} onChange={handleChange}>{GENDERS.map(g => <option key={g} value={g}>{g}</option>)}</Select></div>
                        <div><Label htmlFor="aadhaar" required>Aadhaar Number</Label><Input type="text" name="aadhaar" id="aadhaar" value={formData.aadhaar} onChange={handleChange} required pattern="\d{4}\s?\d{4}\s?\d{4}" title="12 digit Aadhaar number" /></div>
                        <div><Label htmlFor="phone" required>Phone Number</Label><Input type="tel" name="phone" id="phone" value={formData.phone} onChange={handleChange} required pattern="[0-9]{10}" title="10 digit mobile number" /></div>
                        <div><Label htmlFor="email" required>Email Address</Label><Input type="email" name="email" id="email" value={formData.email} onChange={handleChange} required /></div>
                        <div><Label htmlFor="education">Education</Label><Input type="text" name="education" id="education" value={formData.education} onChange={handleChange} /></div>
                        <div className="md:col-span-2"><Label htmlFor="photo">Upload Artisan Photo</Label><Input type="file" name="photo" id="photo" onChange={handleFileChange} accept="image/*" className="p-0 file:p-2.5 file:border-0 file:mr-4 file:bg-gray-100 file:text-gray-700 hover:file:bg-gray-200" /></div>
                    </div>
                </Card>

                <Card>
                    <SectionHeader title="Address Details" />
                    <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="md:col-span-2"><Label htmlFor="address" required>Full Address</Label><Textarea name="address" id="address" value={formData.address} onChange={handleChange} rows={3} required /></div>
                        <div><Label htmlFor="state" required>State</Label><Select name="state" id="state" value={formData.state} onChange={handleChange}>{NORTHEAST_STATES.map(s => <option key={s} value={s}>{s}</option>)}</Select></div>
                        <div><Label htmlFor="district" required>District</Label><Input type="text" name="district" id="district" value={formData.district} onChange={handleChange} required /></div>
                        <div><Label htmlFor="pincode" required>Pin Code</Label><Input type="text" name="pincode" id="pincode" value={formData.pincode} onChange={handleChange} required pattern="[0-9]{6}" title="6 digit pin code" /></div>
                    </div>
                </Card>

                <Card>
                    <SectionHeader title="Community & Other Details" />
                    <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div><Label htmlFor="category" required>Category</Label><Select name="category" id="category" value={formData.category} onChange={handleChange}>{CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}</Select></div>
                        <div><Label htmlFor="minority" required>Minority Status</Label><Select name="minority" id="minority" value={formData.minority} onChange={handleChange}>{YES_NO.map(o => <option key={o} value={o}>{o}</option>)}</Select></div>
                        <div className="md:col-span-2"><Label htmlFor="otherId">Other ID (optional)</Label><Input type="text" name="otherId" id="otherId" value={formData.otherId} onChange={handleChange} /></div>
                    </div>
                </Card>

                <Card>
                    <SectionHeader title="Bank Details" />
                    <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div><Label htmlFor="bankName" required>Bank Name</Label><Input type="text" name="bankName" id="bankName" value={formData.bankName} onChange={handleChange} required /></div>
                        <div><Label htmlFor="accountNumber" required>Account Number</Label><Input type="text" name="accountNumber" id="accountNumber" value={formData.accountNumber} onChange={handleChange} required pattern="\d+" title="Enter a valid account number"/></div>
                        <div><Label htmlFor="ifscCode" required>IFSC Code</Label><Input type="text" name="ifscCode" id="ifscCode" value={formData.ifscCode} onChange={handleChange} required /></div>
                    </div>
                </Card>

                <Card>
                    <SectionHeader title="Craft Details" />
                    <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div><Label htmlFor="craftType">Craft Type</Label><Input type="text" name="craftType" id="craftType" value={craftType} readOnly className="bg-gray-100" /></div>
                        <div><Label htmlFor="experience" required>Years of Experience</Label><Input type="number" name="experience" id="experience" value={formData.experience} onChange={handleChange} required min="0" /></div>
                        <div><Label htmlFor="training" required>Training Received</Label><Select name="training" id="training" value={formData.training} onChange={handleChange}>{YES_NO.map(o => <option key={o} value={o}>{o}</option>)}</Select></div>
                        {formData.training === 'Yes' && <div><Label htmlFor="trainingDetails">Training Details</Label><Input type="text" name="trainingDetails" id="trainingDetails" value={formData.trainingDetails} onChange={handleChange} /></div>}
                        <div className="md:col-span-2"><Label htmlFor="certification">Certification (Handloom Mark, GI Tag, etc.)</Label><Input type="text" name="certification" id="certification" value={formData.certification} onChange={handleChange} /></div>
                    </div>
                </Card>

                <button type="submit" className="w-full bg-green-600 text-white font-bold py-3 px-6 rounded-lg shadow-md hover:bg-green-700 transition duration-300">
                    Submit Registration
                </button>
            </form>
        </div>
    );
};

export default RegistrationPage;
